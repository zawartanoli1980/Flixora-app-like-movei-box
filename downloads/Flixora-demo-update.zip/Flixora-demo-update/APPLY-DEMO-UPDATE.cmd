@echo off
setlocal
cd /d "%~dp0"
node "%~dp0APPLY-DEMO-UPDATE.cjs"
if errorlevel 1 (
  pause
  exit /b 1
)
